# Config Management System

Java application demonstrating Singleton, Builder, Strategy, Observer, and Composite design patterns.

## Patterns implemented

| Pattern   | Where                                              |
|-----------|----------------------------------------------------|
| Singleton | `Config.getInstance()` — global config access      |
| Builder   | `ConfigEntry.Builder`, `ConfigProfile.Builder`, `ConfigChangeEvent.Builder` |
| Strategy  | `ConfigSource` interface → `FileConfigSource`, `DatabaseConfigSource`, `ApiConfigSource` |
| Observer  | `ConfigSubject / ConfigObserver` → `CacheReloadObserver`, `ConnectionUpdateObserver` |
| Composite | `ConfigComponent` → `ConfigNode` (profile/module) + `ConfigLeaf` (parameter) |

## Package structure

```
com.configsystem
├── entity/          — ConfigEntry, ConfigProfile, ConfigSourceType (no business logic)
├── exception/       — ConfigException, ValidationException, ParseException, SourceException
├── validator/       — EntryValidator, ConfigEntryValidator, ProfileValidator
├── parser/          — ConfigFileParser, KeyValueParser
├── source/          — ConfigSource, FileConfigSource, DatabaseConfigSource, ApiConfigSource
├── observer/        — ConfigObserver, ConfigSubject, ConfigChangeEvent, *Observer impls
├── composite/       — ConfigComponent, ConfigNode, ConfigLeaf
├── service/         — Config (Singleton), ConfigService
└── util/            — ConfigPrinter
```

## Config file format

File: `src/main/resources/config/application.txt`

```
# Comment line
app.name=MyApp                    # STRING (default)
server.port=8080::INTEGER         # typed
feature.enabled=true::BOOLEAN
storage.url=https://cdn.x.com::URL
```

Malformed lines are **silently skipped** — the parser logs a warning and moves to the next line.

## Requirements satisfied

- ✅ Entity classes contain no business logic
- ✅ Parameters read from `.txt` file; malformed lines skipped
- ✅ Java 8+ I/O: `Files.lines()` + streams
- ✅ Validators for both input data and type-value consistency
- ✅ `toString`, `equals`, `hashCode` overridden (no `Objects.*` utility)
- ✅ All classes organized in packages
- ✅ Custom exception hierarchy
- ✅ Java Code Convention compliant
- ✅ JUnit 5 + Mockito tests (entity, validator, parser, source, composite, observer, service)

## Build & run

```bash
# Build
mvn clean package

# Run tests
mvn test

# Run application
java -cp target/config-system-1.0-SNAPSHOT.jar com.configsystem.Main
```

## Test coverage

| Test class                  | Covers                        |
|-----------------------------|-------------------------------|
| ConfigEntryTest             | Entity equals/hashCode/builder|
| ConfigProfileTest           | Entity equals/hashCode        |
| ConfigEntryValidatorTest    | All types + edge cases        |
| ProfileValidatorTest        | Name regex validation         |
| KeyValueParserTest          | Valid + malformed lines        |
| FileConfigSourceTest        | File loading + skip bad lines |
| DatabaseConfigSourceTest    | Stub data source              |
| ApiConfigSourceTest         | Stub API source               |
| ConfigCompositeTest         | Full tree hierarchy           |
| ObserverTest                | Events + Mockito              |
| ConfigServiceTest           | Integration + Mockito args    |
