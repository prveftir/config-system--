package com.configsystem.util;

import com.configsystem.composite.ConfigComponent;
import com.configsystem.composite.ConfigNode;
import com.configsystem.entity.ConfigEntry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Utility that prints the Composite config tree to the logger.
 */
public final class ConfigPrinter {

    private static final Logger LOGGER = LogManager.getLogger(ConfigPrinter.class);

    private static final String INDENT = "  ";

    private ConfigPrinter() {}

    public static void printTree(ConfigComponent component) {
        printTree(component, 0);
    }

    private static void printTree(ConfigComponent component, int depth) {
        String indent = INDENT.repeat(depth);
        if (component.isLeaf()) {
            component.getEntry(component.getName()).ifPresent(entry ->
                    LOGGER.info("{}[PARAM] {} = {} ({})",
                            indent, entry.getKey(), entry.getValue(), entry.getType()));
        } else {
            LOGGER.info("{}[NODE] {}", indent, component.getName());
            if (component instanceof ConfigNode node) {
                for (ConfigComponent child : node.getChildren()) {
                    printTree(child, depth + 1);
                }
            }
        }
    }

    public static void printEntry(ConfigEntry entry) {
        LOGGER.info("ConfigEntry: key='{}' value='{}' type='{}' source='{}'",
                entry.getKey(), entry.getValue(), entry.getType(), entry.getSourceType());
    }
}
