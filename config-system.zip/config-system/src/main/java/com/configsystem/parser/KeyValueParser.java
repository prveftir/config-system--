package com.configsystem.parser;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.validator.EntryValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

/**
 * Parses lines in format:  key=value[::TYPE]
 * Examples:
 *   app.name=MyApp
 *   server.port=8080::INTEGER
 *   feature.enabled=true::BOOLEAN
 *
 * Malformed lines (no '=', blank key, invalid type) are silently skipped.
 */
public class KeyValueParser implements ConfigFileParser {

    private static final Logger LOGGER = LogManager.getLogger(KeyValueParser.class);

    private static final String KEY_VALUE_SEPARATOR = "=";
    private static final String TYPE_SEPARATOR = "::";

    private final EntryValidator validator;

    public KeyValueParser(EntryValidator validator) {
        this.validator = validator;
    }

    @Override
    public List<ConfigEntry> parseLine(String line, ConfigSourceType sourceType) {
        if (line == null || line.isBlank()) {
            return Collections.emptyList();
        }

        int eqIdx = line.indexOf(KEY_VALUE_SEPARATOR);
        if (eqIdx <= 0) {
            LOGGER.warn("Skipping malformed line (no '='): '{}'", line);
            return Collections.emptyList();
        }

        String rawKey = line.substring(0, eqIdx).trim();
        String rawRest = line.substring(eqIdx + 1);

        String type = "STRING";
        String rawValue;

        int typeIdx = rawRest.indexOf(TYPE_SEPARATOR);
        if (typeIdx >= 0) {
            rawValue = rawRest.substring(0, typeIdx).trim();
            type = rawRest.substring(typeIdx + TYPE_SEPARATOR.length()).trim().toUpperCase();
        } else {
            rawValue = rawRest.trim();
        }

        if (rawKey.isEmpty()) {
            LOGGER.warn("Skipping line with empty key: '{}'", line);
            return Collections.emptyList();
        }

        if (!validator.isValidType(type)) {
            LOGGER.warn("Skipping line with unknown type '{}': '{}'", type, line);
            return Collections.emptyList();
        }

        if (!validator.isValueMatchingType(rawValue, type)) {
            LOGGER.warn("Skipping line — value '{}' does not match type '{}': '{}'",
                    rawValue, type, line);
            return Collections.emptyList();
        }

        ConfigEntry entry = ConfigEntry.builder()
                .key(rawKey)
                .value(rawValue)
                .type(type)
                .sourceType(sourceType)
                .loadedAt(LocalDateTime.now())
                .build();

        return Collections.singletonList(entry);
    }
}
