package com.configsystem.parser;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import java.util.List;
import java.util.Optional;

/**
 * Parser interface for config file lines.
 */
public interface ConfigFileParser {
    /**
     * Parses one line into a ConfigEntry.
     * Returns empty list if the line is malformed — never throws.
     */
    List<ConfigEntry> parseLine(String line, ConfigSourceType sourceType);
}
