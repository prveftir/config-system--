package com.configsystem.composite;

import com.configsystem.entity.ConfigEntry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Composite node — represents a profile or module that can contain
 * child nodes or leaf parameters.
 * Hierarchy: Profile → Module → Parameter
 */
public final class ConfigNode implements ConfigComponent {

    private static final Logger LOGGER = LogManager.getLogger(ConfigNode.class);

    private final String name;
    private final List<ConfigComponent> children = new CopyOnWriteArrayList<>();

    public ConfigNode(String name) {
        this.name = name;
    }

    @Override
    public String getName() { return name; }

    @Override
    public Optional<ConfigEntry> getEntry(String key) {
        for (ConfigComponent child : children) {
            Optional<ConfigEntry> found = child.getEntry(key);
            if (found.isPresent()) {
                return found;
            }
        }
        return Optional.empty();
    }

    @Override
    public List<ConfigEntry> getAllEntries() {
        List<ConfigEntry> result = new ArrayList<>();
        for (ConfigComponent child : children) {
            result.addAll(child.getAllEntries());
        }
        return result;
    }

    @Override
    public void add(ConfigComponent component) {
        children.add(component);
        LOGGER.debug("Added component '{}' to node '{}'", component.getName(), this.name);
    }

    @Override
    public void remove(String name) {
        children.removeIf(c -> c.getName().equals(name));
        LOGGER.debug("Removed component '{}' from node '{}'", name, this.name);
    }

    @Override
    public boolean isLeaf() { return false; }

    public List<ConfigComponent> getChildren() {
        return new ArrayList<>(children);
    }

    @Override
    public String toString() {
        return "ConfigNode{name='" + name + "', children=" + children.size() + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigNode that = (ConfigNode) o;
        return this.name == null ? that.name == null : this.name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return 31 + (name != null ? name.hashCode() : 0);
    }
}
