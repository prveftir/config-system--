package com.configsystem.composite;

import com.configsystem.entity.ConfigEntry;
import java.util.List;
import java.util.Optional;

/**
 * Composite component — can be a leaf (parameter) or a node (profile/module).
 */
public interface ConfigComponent {
    String getName();
    Optional<ConfigEntry> getEntry(String key);
    List<ConfigEntry> getAllEntries();
    void add(ConfigComponent component);
    void remove(String name);
    boolean isLeaf();
}
