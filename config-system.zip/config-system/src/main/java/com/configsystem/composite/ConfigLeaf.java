package com.configsystem.composite;

import com.configsystem.entity.ConfigEntry;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Leaf node — holds a single ConfigEntry (one key=value parameter).
 */
public final class ConfigLeaf implements ConfigComponent {

    private final ConfigEntry entry;

    public ConfigLeaf(ConfigEntry entry) {
        this.entry = entry;
    }

    @Override
    public String getName() { return entry.getKey(); }

    @Override
    public Optional<ConfigEntry> getEntry(String key) {
        if (entry.getKey().equals(key)) {
            return Optional.of(entry);
        }
        return Optional.empty();
    }

    @Override
    public List<ConfigEntry> getAllEntries() {
        return Collections.singletonList(entry);
    }

    @Override
    public void add(ConfigComponent component) {
        throw new UnsupportedOperationException("Leaf cannot contain children");
    }

    @Override
    public void remove(String name) {
        throw new UnsupportedOperationException("Leaf cannot remove children");
    }

    @Override
    public boolean isLeaf() { return true; }

    @Override
    public String toString() {
        return "ConfigLeaf{entry=" + entry + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigLeaf that = (ConfigLeaf) o;
        return this.entry == null ? that.entry == null : this.entry.equals(that.entry);
    }

    @Override
    public int hashCode() {
        return 31 + (entry != null ? entry.hashCode() : 0);
    }
}
