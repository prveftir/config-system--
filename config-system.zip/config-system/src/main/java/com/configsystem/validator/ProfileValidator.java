package com.configsystem.validator;

import com.configsystem.entity.ConfigProfile;

/**
 * Validates ConfigProfile objects.
 */
public class ProfileValidator {

    private static final String NAME_PATTERN = "^[a-zA-Z][a-zA-Z0-9_\\-]{1,49}$";

    public boolean isValid(ConfigProfile profile) {
        if (profile == null) {
            return false;
        }
        return isValidName(profile.getName());
    }

    public boolean isValidName(String name) {
        if (name == null || name.isBlank()) {
            return false;
        }
        return name.matches(NAME_PATTERN);
    }
}
