package com.configsystem.validator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Set;

/**
 * Concrete validator for config entry raw data.
 * Validates type names and value–type consistency.
 */
public class ConfigEntryValidator implements EntryValidator {

    private static final Logger LOGGER = LogManager.getLogger(ConfigEntryValidator.class);

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "STRING", "INTEGER", "LONG", "DOUBLE", "BOOLEAN", "URL", "PATH"
    );

    private static final String KEY_PATTERN = "^[a-zA-Z][a-zA-Z0-9._\\-]*$";

    @Override
    public boolean isValidType(String type) {
        if (type == null || type.isBlank()) {
            LOGGER.debug("Type is null or blank");
            return false;
        }
        return ALLOWED_TYPES.contains(type.toUpperCase());
    }

    @Override
    public boolean isValueMatchingType(String value, String type) {
        if (value == null || type == null) {
            return false;
        }
        switch (type.toUpperCase()) {
            case "INTEGER": return isInteger(value);
            case "LONG":    return isLong(value);
            case "DOUBLE":  return isDouble(value);
            case "BOOLEAN": return isBoolean(value);
            case "URL":     return isUrl(value);
            case "PATH":    return isPath(value);
            default:        return !value.isEmpty();
        }
    }

    @Override
    public boolean isValidKey(String key) {
        if (key == null || key.isBlank()) {
            return false;
        }
        return key.matches(KEY_PATTERN);
    }

    private boolean isInteger(String v) {
        try { Integer.parseInt(v); return true; }
        catch (NumberFormatException e) { return false; }
    }

    private boolean isLong(String v) {
        try { Long.parseLong(v); return true; }
        catch (NumberFormatException e) { return false; }
    }

    private boolean isDouble(String v) {
        try { Double.parseDouble(v); return true; }
        catch (NumberFormatException e) { return false; }
    }

    private boolean isBoolean(String v) {
        return "true".equalsIgnoreCase(v) || "false".equalsIgnoreCase(v);
    }

    private boolean isUrl(String v) {
        return v.startsWith("http://") || v.startsWith("https://");
    }

    private boolean isPath(String v) {
        return !v.isBlank() && !v.contains("\0");
    }
}
