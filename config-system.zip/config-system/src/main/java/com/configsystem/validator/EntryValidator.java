package com.configsystem.validator;

/**
 * Validates raw data before ConfigEntry construction.
 */
public interface EntryValidator {
    boolean isValidType(String type);
    boolean isValueMatchingType(String value, String type);
    boolean isValidKey(String key);
}
