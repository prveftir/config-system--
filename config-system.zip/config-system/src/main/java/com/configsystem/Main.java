package com.configsystem;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigProfile;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.observer.CacheReloadObserver;
import com.configsystem.observer.ConnectionUpdateObserver;
import com.configsystem.parser.KeyValueParser;
import com.configsystem.service.Config;
import com.configsystem.service.ConfigService;
import com.configsystem.source.ApiConfigSource;
import com.configsystem.source.DatabaseConfigSource;
import com.configsystem.source.FileConfigSource;
import com.configsystem.util.ConfigPrinter;
import com.configsystem.validator.ConfigEntryValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;

/**
 * Application entry point — demonstrates all patterns.
 */
public class Main {

    private static final Logger LOGGER = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        LOGGER.info("=== Config Management System started ===");

        Config config = Config.getInstance();
        ConfigService service = new ConfigService(config);

        // ── 1. Register observers (Observer pattern)
        service.registerObserver(new CacheReloadObserver());
        service.registerObserver(new ConnectionUpdateObserver());
        LOGGER.info("Observers registered");

        // ── 2. Load from FILE (Strategy + Composite)
        try {
            ConfigEntryValidator validator = new ConfigEntryValidator();
            KeyValueParser parser = new KeyValueParser(validator);

            FileConfigSource fileSource = new FileConfigSource(
                    "config/application.txt", parser);
            ConfigProfile devProfile = ConfigProfile.builder()
                    .name("development")
                    .description("Dev settings")
                    .active(true)
                    .build();
            service.loadSource(fileSource, devProfile);
        } catch (Exception e) {
            LOGGER.error("File source load failed", e);
        }

        // ── 3. Load from DATABASE (Strategy)
        try {
            ConfigProfile dbProfile = ConfigProfile.builder()
                    .name("database-profile")
                    .description("DB settings")
                    .active(true)
                    .build();
            service.loadSource(new DatabaseConfigSource(), dbProfile);
        } catch (Exception e) {
            LOGGER.error("DB source load failed", e);
        }

        // ── 4. Load from API (Strategy)
        try {
            ConfigProfile apiProfile = ConfigProfile.builder()
                    .name("remote-api")
                    .description("Remote feature flags")
                    .active(true)
                    .build();
            service.loadSource(new ApiConfigSource("https://config.example.com/api/v1"), apiProfile);
        } catch (Exception e) {
            LOGGER.error("API source load failed", e);
        }

        // ── 5. Query values
        LOGGER.info("--- Querying config values ---");
        LOGGER.info("app.name = {}", service.getValueOrDefault("app.name", "unknown"));
        LOGGER.info("db.host  = {}", service.getValueOrDefault("db.host", "127.0.0.1"));
        LOGGER.info("api.timeout.ms = {}", service.getValueOrDefault("api.timeout.ms", "3000"));

        // ── 6. Runtime update (triggers observers)
        LOGGER.info("--- Runtime update ---");
        ConfigEntry updatedEntry = ConfigEntry.builder()
                .key("app.version")
                .value("2.0.0")
                .type("STRING")
                .sourceType(ConfigSourceType.FILE)
                .loadedAt(LocalDateTime.now())
                .build();
        service.updateEntry("development", updatedEntry);
        LOGGER.info("Updated app.version = {}",
                service.getValueOrDefault("app.version", "none"));

        // ── 7. Print Composite tree
        LOGGER.info("--- Config Composite Tree ---");
        ConfigPrinter.printTree(config.getCompositeTree());

        // ── 8. Summary
        LOGGER.info("Total entries loaded: {}", service.listAll().size());
        LOGGER.info("=== Config Management System finished ===");
    }
}
