package com.configsystem.observer;

/**
 * Observer interface — receives configuration change events.
 */
public interface ConfigObserver {
    void onConfigChanged(ConfigChangeEvent event);
}
