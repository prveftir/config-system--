package com.configsystem.observer;

/**
 * Subject interface for the Observer pattern.
 */
public interface ConfigSubject {
    void addObserver(ConfigObserver observer);
    void removeObserver(ConfigObserver observer);
    void notifyObservers(ConfigChangeEvent event);
}
