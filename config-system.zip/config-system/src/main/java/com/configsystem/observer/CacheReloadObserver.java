package com.configsystem.observer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Observer that reloads cache on configuration change.
 */
public class CacheReloadObserver implements ConfigObserver {

    private static final Logger LOGGER = LogManager.getLogger(CacheReloadObserver.class);

    @Override
    public void onConfigChanged(ConfigChangeEvent event) {
        LOGGER.info("Cache reload triggered by event: {}", event.getChangeType());
        performCacheReload(event);
    }

    private void performCacheReload(ConfigChangeEvent event) {
        LOGGER.debug("Clearing cache for key: {}",
                event.getEntry() != null ? event.getEntry().getKey() : "ALL");
    }
}
