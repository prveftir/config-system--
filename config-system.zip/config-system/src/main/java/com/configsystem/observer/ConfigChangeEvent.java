package com.configsystem.observer;

import com.configsystem.entity.ConfigEntry;
import java.time.LocalDateTime;

public final class ConfigChangeEvent {

    public enum ChangeType { ADDED, UPDATED, REMOVED, RELOADED }

    private final ChangeType changeType;
    private final ConfigEntry entry;
    private final LocalDateTime occurredAt;

    private ConfigChangeEvent(Builder builder) {
        this.changeType = builder.changeType;
        this.entry = builder.entry;
        this.occurredAt = builder.occurredAt;
    }

    public ChangeType getChangeType() { return changeType; }
    public ConfigEntry getEntry() { return entry; }
    public LocalDateTime getOccurredAt() { return occurredAt; }

    @Override
    public String toString() {
        return "ConfigChangeEvent{changeType=" + changeType
                + ", entry=" + entry
                + ", occurredAt=" + occurredAt + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigChangeEvent that = (ConfigChangeEvent) o;
        return this.changeType == that.changeType
                && (this.entry == null ? that.entry == null : this.entry.equals(that.entry));
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (changeType != null ? changeType.hashCode() : 0);
        result = 31 * result + (entry != null ? entry.hashCode() : 0);
        return result;
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private ChangeType changeType;
        private ConfigEntry entry;
        private LocalDateTime occurredAt = LocalDateTime.now();

        private Builder() {}

        public Builder changeType(ChangeType changeType) { this.changeType = changeType; return this; }
        public Builder entry(ConfigEntry entry) { this.entry = entry; return this; }
        public Builder occurredAt(LocalDateTime occurredAt) { this.occurredAt = occurredAt; return this; }

        public ConfigChangeEvent build() { return new ConfigChangeEvent(this); }
    }
}
