package com.configsystem.observer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Observer that refreshes DB / API connections on config change.
 */
public class ConnectionUpdateObserver implements ConfigObserver {

    private static final Logger LOGGER = LogManager.getLogger(ConnectionUpdateObserver.class);

    @Override
    public void onConfigChanged(ConfigChangeEvent event) {
        LOGGER.info("Connection update triggered. Change type: {}", event.getChangeType());
        if (event.getEntry() != null && isConnectionRelatedKey(event.getEntry().getKey())) {
            LOGGER.debug("Reconnecting because key '{}' changed", event.getEntry().getKey());
        }
    }

    private boolean isConnectionRelatedKey(String key) {
        return key != null && (key.startsWith("db.") || key.startsWith("api."));
    }
}
