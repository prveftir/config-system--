package com.configsystem.entity;

import java.time.LocalDateTime;

/**
 * Immutable entity representing a single configuration parameter.
 * No business logic methods — only data.
 */
public final class ConfigEntry {

    private final String key;
    private final String value;
    private final String type;
    private final ConfigSourceType sourceType;
    private final LocalDateTime loadedAt;

    private ConfigEntry(Builder builder) {
        this.key = builder.key;
        this.value = builder.value;
        this.type = builder.type;
        this.sourceType = builder.sourceType;
        this.loadedAt = builder.loadedAt;
    }

    public String getKey() { return key; }
    public String getValue() { return value; }
    public String getType() { return type; }
    public ConfigSourceType getSourceType() { return sourceType; }
    public LocalDateTime getLoadedAt() { return loadedAt; }

    @Override
    public String toString() {
        return "ConfigEntry{"
                + "key='" + key + '\''
                + ", value='" + value + '\''
                + ", type='" + type + '\''
                + ", sourceType=" + sourceType
                + ", loadedAt=" + loadedAt
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigEntry that = (ConfigEntry) o;
        return keyEquals(this.key, that.key)
                && keyEquals(this.value, that.value)
                && keyEquals(this.type, that.type)
                && this.sourceType == that.sourceType;
    }

    private boolean keyEquals(String a, String b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.equals(b);
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (key != null ? key.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (sourceType != null ? sourceType.hashCode() : 0);
        return result;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private String key;
        private String value;
        private String type = "STRING";
        private ConfigSourceType sourceType = ConfigSourceType.FILE;
        private LocalDateTime loadedAt = LocalDateTime.now();

        private Builder() {}

        public Builder key(String key) { this.key = key; return this; }
        public Builder value(String value) { this.value = value; return this; }
        public Builder type(String type) { this.type = type; return this; }
        public Builder sourceType(ConfigSourceType sourceType) { this.sourceType = sourceType; return this; }
        public Builder loadedAt(LocalDateTime loadedAt) { this.loadedAt = loadedAt; return this; }

        public ConfigEntry build() {
            return new ConfigEntry(this);
        }
    }
}
