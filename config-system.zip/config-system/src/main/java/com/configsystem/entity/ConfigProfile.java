package com.configsystem.entity;

/**
 * Entity representing a named configuration profile (e.g. dev, prod).
 * Pure data container — no logic.
 */
public final class ConfigProfile {

    private final String name;
    private final String description;
    private final boolean active;

    private ConfigProfile(Builder builder) {
        this.name = builder.name;
        this.description = builder.description;
        this.active = builder.active;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public boolean isActive() { return active; }

    @Override
    public String toString() {
        return "ConfigProfile{"
                + "name='" + name + '\''
                + ", description='" + description + '\''
                + ", active=" + active
                + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConfigProfile that = (ConfigProfile) o;
        if (this.active != that.active) return false;
        if (this.name == null ? that.name != null : !this.name.equals(that.name)) return false;
        return this.description == null ? that.description == null : this.description.equals(that.description);
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (active ? 1 : 0);
        return result;
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private String name;
        private String description = "";
        private boolean active = true;

        private Builder() {}

        public Builder name(String name) { this.name = name; return this; }
        public Builder description(String description) { this.description = description; return this; }
        public Builder active(boolean active) { this.active = active; return this; }

        public ConfigProfile build() { return new ConfigProfile(this); }
    }
}
