package com.configsystem.entity;

public enum ConfigSourceType {
    FILE, DATABASE, API
}
