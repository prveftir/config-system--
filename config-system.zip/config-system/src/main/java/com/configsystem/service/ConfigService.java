package com.configsystem.service;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigProfile;
import com.configsystem.exception.ConfigException;
import com.configsystem.observer.ConfigObserver;
import com.configsystem.source.ConfigSource;

import java.util.List;
import java.util.Optional;

/**
 * Facade service — orchestrates loading, querying, and updates.
 */
public class ConfigService {

    private final Config config;

    public ConfigService(Config config) {
        this.config = config;
    }

    public void registerObserver(ConfigObserver observer) {
        config.addObserver(observer);
    }

    public void loadSource(ConfigSource source, ConfigProfile profile)
            throws ConfigException {
        config.loadFromSource(source, profile);
    }

    public Optional<String> getValue(String key) {
        return config.get(key);
    }

    public Optional<ConfigEntry> getEntry(String key) {
        return config.getEntry(key);
    }

    public List<ConfigEntry> listAll() {
        return config.getAllEntries();
    }

    public void updateEntry(String profile, ConfigEntry entry) {
        config.set(profile, entry);
    }

    public String getValueOrDefault(String key, String defaultValue) {
        return config.get(key).orElse(defaultValue);
    }
}
