package com.configsystem.service;

import com.configsystem.composite.ConfigComponent;
import com.configsystem.composite.ConfigLeaf;
import com.configsystem.composite.ConfigNode;
import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigProfile;
import com.configsystem.exception.ConfigException;
import com.configsystem.exception.ValidationException;
import com.configsystem.observer.ConfigChangeEvent;
import com.configsystem.observer.ConfigObserver;
import com.configsystem.observer.ConfigSubject;
import com.configsystem.source.ConfigSource;
import com.configsystem.validator.ProfileValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Singleton — global access point to the configuration.
 * Thread-safe via ReentrantReadWriteLock + volatile instance.
 *
 * Implements:
 *  - Singleton pattern
 *  - ConfigSubject (Observer pattern)
 *  - Delegates to Composite tree for hierarchical config
 */
public final class Config implements ConfigSubject {

    private static final Logger LOGGER = LogManager.getLogger(Config.class);

    private static volatile Config instance;

    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final List<ConfigObserver> observers = new CopyOnWriteArrayList<>();
    private final ProfileValidator profileValidator = new ProfileValidator();

    // Root of Composite tree  (profile → module → parameter)
    private ConfigComponent root = new ConfigNode("ROOT");

    // ── Singleton ───────────────────────────────────────────────
    private Config() {}

    public static Config getInstance() {
        if (instance == null) {
            synchronized (Config.class) {
                if (instance == null) {
                    instance = new Config();
                    LOGGER.info("Config singleton created");
                }
            }
        }
        return instance;
    }

    // ── Observer ────────────────────────────────────────────────
    @Override
    public void addObserver(ConfigObserver observer) {
        observers.add(observer);
        LOGGER.debug("Observer added: {}", observer.getClass().getSimpleName());
    }

    @Override
    public void removeObserver(ConfigObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(ConfigChangeEvent event) {
        for (ConfigObserver observer : observers) {
            observer.onConfigChanged(event);
        }
    }

    // ── Load from source (Strategy) ─────────────────────────────
    /**
     * Loads entries from the given source and registers them under
     * a new profile node in the Composite tree.
     */
    public void loadFromSource(ConfigSource source, ConfigProfile profile)
            throws ConfigException {
        if (!profileValidator.isValid(profile)) {
            throw new ValidationException(
                    "Invalid profile name: " + profile.getName());
        }

        LOGGER.info("Loading from source '{}' into profile '{}'",
                source.getSourceName(), profile.getName());

        List<ConfigEntry> entries = source.load();

        lock.writeLock().lock();
        try {
            ConfigNode profileNode = new ConfigNode(profile.getName());
            for (ConfigEntry entry : entries) {
                profileNode.add(new ConfigLeaf(entry));
            }
            root.add(profileNode);
        } finally {
            lock.writeLock().unlock();
        }

        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.RELOADED)
                .build();
        notifyObservers(event);
        LOGGER.info("Loaded {} entries from '{}'", entries.size(), source.getSourceName());
    }

    // ── Read ────────────────────────────────────────────────────
    public Optional<String> get(String key) {
        lock.readLock().lock();
        try {
            return root.getEntry(key).map(ConfigEntry::getValue);
        } finally {
            lock.readLock().unlock();
        }
    }

    public Optional<ConfigEntry> getEntry(String key) {
        lock.readLock().lock();
        try {
            return root.getEntry(key);
        } finally {
            lock.readLock().unlock();
        }
    }

    public List<ConfigEntry> getAllEntries() {
        lock.readLock().lock();
        try {
            return new ArrayList<>(root.getAllEntries());
        } finally {
            lock.readLock().unlock();
        }
    }

    // ── Write ───────────────────────────────────────────────────
    public void set(String profileName, ConfigEntry entry) {
        lock.writeLock().lock();
        try {
            Optional<ConfigEntry> existing = root.getEntry(entry.getKey());

            // Find or create profile node
            ConfigNode profileNode = findOrCreateProfile(profileName);
            profileNode.remove(entry.getKey());
            profileNode.add(new ConfigLeaf(entry));

            ConfigChangeEvent.ChangeType changeType = existing.isPresent()
                    ? ConfigChangeEvent.ChangeType.UPDATED
                    : ConfigChangeEvent.ChangeType.ADDED;

            ConfigChangeEvent event = ConfigChangeEvent.builder()
                    .changeType(changeType)
                    .entry(entry)
                    .build();
            notifyObservers(event);

            LOGGER.info("Config entry '{}' {} in profile '{}'",
                    entry.getKey(), changeType, profileName);
        } finally {
            lock.writeLock().unlock();
        }
    }

    // ── Reset (for tests) ───────────────────────────────────────
    public void reset() {
        lock.writeLock().lock();
        try {
            root = new ConfigNode("ROOT");
            LOGGER.info("Config reset");
        } finally {
            lock.writeLock().unlock();
        }
    }

    // ── Composite helpers ────────────────────────────────────────
    public ConfigComponent getCompositeTree() {
        lock.readLock().lock();
        try {
            return root;
        } finally {
            lock.readLock().unlock();
        }
    }

    private ConfigNode findOrCreateProfile(String profileName) {
        // Search in existing children of root
        if (root instanceof ConfigNode rootNode) {
            for (ConfigComponent child : rootNode.getChildren()) {
                if (child.getName().equals(profileName) && !child.isLeaf()) {
                    return (ConfigNode) child;
                }
            }
        }
        ConfigNode newProfile = new ConfigNode(profileName);
        root.add(newProfile);
        return newProfile;
    }
}
