package com.configsystem.exception;
public class ParseException extends ConfigException {
    public ParseException(String message) { super(message); }
    public ParseException(String message, Throwable cause) { super(message, cause); }
}
