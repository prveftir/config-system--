package com.configsystem.exception;
public class SourceException extends ConfigException {
    public SourceException(String message) { super(message); }
    public SourceException(String message, Throwable cause) { super(message, cause); }
}
