package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.exception.SourceException;
import java.util.List;

/**
 * Strategy interface — each implementation is a config source.
 */
public interface ConfigSource {
    List<ConfigEntry> load() throws SourceException;
    String getSourceName();
}
