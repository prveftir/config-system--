package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.exception.SourceException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Strategy: loads configuration from a database.
 * In this implementation, provides stub data simulating a DB query.
 * In production, replace the stub with a real JDBC / JPA call.
 */
public class DatabaseConfigSource implements ConfigSource {

    private static final Logger LOGGER = LogManager.getLogger(DatabaseConfigSource.class);

    private static final String SOURCE_NAME = "DATABASE";

    @Override
    public List<ConfigEntry> load() throws SourceException {
        LOGGER.info("Loading config from database source (stub)");
        return buildStubEntries();
    }

    private List<ConfigEntry> buildStubEntries() {
        List<ConfigEntry> entries = new ArrayList<>();
        entries.add(ConfigEntry.builder()
                .key("db.host")
                .value("localhost")
                .type("STRING")
                .sourceType(ConfigSourceType.DATABASE)
                .loadedAt(LocalDateTime.now())
                .build());
        entries.add(ConfigEntry.builder()
                .key("db.port")
                .value("5432")
                .type("INTEGER")
                .sourceType(ConfigSourceType.DATABASE)
                .loadedAt(LocalDateTime.now())
                .build());
        entries.add(ConfigEntry.builder()
                .key("db.pool.size")
                .value("10")
                .type("INTEGER")
                .sourceType(ConfigSourceType.DATABASE)
                .loadedAt(LocalDateTime.now())
                .build());
        entries.add(ConfigEntry.builder()
                .key("db.name")
                .value("appdb")
                .type("STRING")
                .sourceType(ConfigSourceType.DATABASE)
                .loadedAt(LocalDateTime.now())
                .build());
        return entries;
    }

    @Override
    public String getSourceName() {
        return SOURCE_NAME;
    }
}
