package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.exception.SourceException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Strategy: loads configuration from a remote API.
 * Stub implementation — replace with real HTTP client in production.
 */
public class ApiConfigSource implements ConfigSource {

    private static final Logger LOGGER = LogManager.getLogger(ApiConfigSource.class);

    private static final String SOURCE_NAME = "API";

    private final String apiUrl;

    public ApiConfigSource(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    @Override
    public List<ConfigEntry> load() throws SourceException {
        LOGGER.info("Loading config from API: {}", apiUrl);
        return buildStubEntries();
    }

    private List<ConfigEntry> buildStubEntries() {
        List<ConfigEntry> entries = new ArrayList<>();
        entries.add(ConfigEntry.builder()
                .key("api.timeout.ms")
                .value("5000")
                .type("INTEGER")
                .sourceType(ConfigSourceType.API)
                .loadedAt(LocalDateTime.now())
                .build());
        entries.add(ConfigEntry.builder()
                .key("api.retry.count")
                .value("3")
                .type("INTEGER")
                .sourceType(ConfigSourceType.API)
                .loadedAt(LocalDateTime.now())
                .build());
        entries.add(ConfigEntry.builder()
                .key("feature.dark-mode")
                .value("true")
                .type("BOOLEAN")
                .sourceType(ConfigSourceType.API)
                .loadedAt(LocalDateTime.now())
                .build());
        return entries;
    }

    @Override
    public String getSourceName() {
        return SOURCE_NAME + ":" + apiUrl;
    }
}
