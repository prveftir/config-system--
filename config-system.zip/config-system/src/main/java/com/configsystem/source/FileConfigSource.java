package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.exception.SourceException;
import com.configsystem.parser.ConfigFileParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Strategy: loads configuration from a .txt file on classpath.
 * Uses Java-8+ Files.lines() / streams.
 * Skips malformed lines — does NOT throw on bad data.
 */
public class FileConfigSource implements ConfigSource {

    private static final Logger LOGGER = LogManager.getLogger(FileConfigSource.class);

    private final String classpathResource;
    private final ConfigFileParser parser;

    public FileConfigSource(String classpathResource, ConfigFileParser parser) {
        this.classpathResource = classpathResource;
        this.parser = parser;
    }

    @Override
    public List<ConfigEntry> load() throws SourceException {
        Path path = resolvePath();
        LOGGER.info("Loading config from file: {}", path);
        try (Stream<String> lines = Files.lines(path)) {
            return lines
                    .filter(line -> !line.isBlank())
                    .filter(line -> !line.startsWith("#"))
                    .flatMap(line -> parser.parseLine(line, ConfigSourceType.FILE).stream())
                    .collect(Collectors.toList());
        } catch (IOException e) {
            throw new SourceException("Failed to read config file: " + classpathResource, e);
        }
    }

    private Path resolvePath() throws SourceException {
        URL url = Thread.currentThread().getContextClassLoader()
                .getResource(classpathResource);
        if (url == null) {
            throw new SourceException("Classpath resource not found: " + classpathResource);
        }
        try {
            return Paths.get(url.toURI());
        } catch (URISyntaxException e) {
            throw new SourceException("Invalid URI for resource: " + classpathResource, e);
        }
    }

    @Override
    public String getSourceName() {
        return "FILE:" + classpathResource;
    }
}
