package com.configsystem.entity;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ConfigProfile entity tests")
class ConfigProfileTest {

    @Test
    @DisplayName("Builder creates profile with correct fields")
    void builderCreatesProfile() {
        ConfigProfile p = ConfigProfile.builder()
                .name("production").description("Prod env").active(true).build();
        assertEquals("production", p.getName());
        assertEquals("Prod env", p.getDescription());
        assertTrue(p.isActive());
    }

    @Test
    @DisplayName("equals: same name+description+active are equal")
    void equalsWorksCorrectly() {
        ConfigProfile a = ConfigProfile.builder().name("dev").description("d").active(true).build();
        ConfigProfile b = ConfigProfile.builder().name("dev").description("d").active(true).build();
        assertEquals(a, b);
    }

    @Test
    @DisplayName("equals: different active flag — not equal")
    void equalsDifferentActive() {
        ConfigProfile a = ConfigProfile.builder().name("dev").active(true).build();
        ConfigProfile b = ConfigProfile.builder().name("dev").active(false).build();
        assertNotEquals(a, b);
    }

    @Test
    @DisplayName("hashCode: equal objects same hash")
    void hashCodeConsistent() {
        ConfigProfile a = ConfigProfile.builder().name("qa").description("x").active(false).build();
        ConfigProfile b = ConfigProfile.builder().name("qa").description("x").active(false).build();
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    @DisplayName("toString contains name")
    void toStringContainsName() {
        ConfigProfile p = ConfigProfile.builder().name("staging").build();
        assertTrue(p.toString().contains("staging"));
    }
}
