package com.configsystem.entity;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ConfigEntry entity tests")
class ConfigEntryTest {

    @Test
    @DisplayName("Builder creates entry with all fields")
    void builderCreatesEntryWithAllFields() {
        LocalDateTime now = LocalDateTime.of(2024, 1, 15, 12, 0, 0);
        ConfigEntry entry = ConfigEntry.builder()
                .key("app.name").value("MyApp").type("STRING")
                .sourceType(ConfigSourceType.FILE).loadedAt(now).build();
        assertEquals("app.name", entry.getKey());
        assertEquals("MyApp", entry.getValue());
        assertEquals("STRING", entry.getType());
        assertEquals(ConfigSourceType.FILE, entry.getSourceType());
        assertEquals(now, entry.getLoadedAt());
    }

    @Test
    @DisplayName("Default type is STRING")
    void builderDefaultTypeIsString() {
        ConfigEntry e = ConfigEntry.builder().key("k").value("v").build();
        assertEquals("STRING", e.getType());
    }

    @Test
    @DisplayName("equals: same fields are equal")
    void equalsReturnsTrueForSameFields() {
        ConfigEntry a = ConfigEntry.builder().key("x").value("y").type("STRING").sourceType(ConfigSourceType.FILE).build();
        ConfigEntry b = ConfigEntry.builder().key("x").value("y").type("STRING").sourceType(ConfigSourceType.FILE).build();
        assertEquals(a, b);
    }

    @Test
    @DisplayName("equals: different key — not equal")
    void equalsReturnsFalseForDifferentKey() {
        ConfigEntry a = ConfigEntry.builder().key("a").value("v").build();
        ConfigEntry b = ConfigEntry.builder().key("b").value("v").build();
        assertNotEquals(a, b);
    }

    @Test
    @DisplayName("equals: reflexive")
    void equalsReflexive() {
        ConfigEntry a = ConfigEntry.builder().key("k").value("v").build();
        assertEquals(a, a);
    }

    @Test
    @DisplayName("equals: null returns false")
    void equalsNullReturnsFalse() {
        ConfigEntry a = ConfigEntry.builder().key("k").value("v").build();
        assertNotEquals(a, null);
    }

    @Test
    @DisplayName("hashCode: equal objects same hash")
    void hashCodeConsistentWithEquals() {
        ConfigEntry a = ConfigEntry.builder().key("k").value("v").type("STRING").sourceType(ConfigSourceType.DATABASE).build();
        ConfigEntry b = ConfigEntry.builder().key("k").value("v").type("STRING").sourceType(ConfigSourceType.DATABASE).build();
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    @DisplayName("toString contains key and value")
    void toStringContainsKeyAndValue() {
        ConfigEntry entry = ConfigEntry.builder().key("myKey").value("myValue").build();
        assertTrue(entry.toString().contains("myKey"));
        assertTrue(entry.toString().contains("myValue"));
    }
}
