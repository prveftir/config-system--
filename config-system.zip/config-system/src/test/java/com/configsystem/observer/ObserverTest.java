package com.configsystem.observer;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Observer pattern tests")
class ObserverTest {

    @Mock
    private ConfigObserver mockObserver;

    @Test
    @DisplayName("ConfigChangeEvent builder sets all fields")
    void eventBuilderSetsAllFields() {
        ConfigEntry entry = ConfigEntry.builder()
                .key("k").value("v").sourceType(ConfigSourceType.FILE).build();
        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.UPDATED)
                .entry(entry)
                .build();

        assertEquals(ConfigChangeEvent.ChangeType.UPDATED, event.getChangeType());
        assertEquals(entry, event.getEntry());
        assertNotNull(event.getOccurredAt());
    }

    @Test
    @DisplayName("ConfigChangeEvent equals and hashCode")
    void eventEqualsAndHashCode() {
        ConfigEntry e = ConfigEntry.builder().key("k").value("v").build();
        ConfigChangeEvent a = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.ADDED).entry(e).build();
        ConfigChangeEvent b = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.ADDED).entry(e).build();
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    @DisplayName("CacheReloadObserver calls onConfigChanged without exception")
    void cacheReloadObserverNoException() {
        CacheReloadObserver observer = new CacheReloadObserver();
        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.RELOADED).build();
        assertDoesNotThrow(() -> observer.onConfigChanged(event));
    }

    @Test
    @DisplayName("ConnectionUpdateObserver calls onConfigChanged without exception")
    void connectionUpdateObserverNoException() {
        ConnectionUpdateObserver observer = new ConnectionUpdateObserver();
        ConfigEntry dbEntry = ConfigEntry.builder()
                .key("db.host").value("localhost").sourceType(ConfigSourceType.DATABASE).build();
        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.UPDATED)
                .entry(dbEntry).build();
        assertDoesNotThrow(() -> observer.onConfigChanged(event));
    }

    @Test
    @DisplayName("Mock observer is called when event fired")
    void mockObserverIsCalled() {
        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.ADDED).build();
        mockObserver.onConfigChanged(event);
        verify(mockObserver, times(1)).onConfigChanged(event);
    }

    @Test
    @DisplayName("Multiple observers all notified")
    void multipleObserversAllNotified() {
        List<ConfigChangeEvent> received = new ArrayList<>();
        ConfigObserver obs1 = received::add;
        ConfigObserver obs2 = received::add;

        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.RELOADED).build();

        obs1.onConfigChanged(event);
        obs2.onConfigChanged(event);

        assertEquals(2, received.size());
    }

    @Test
    @DisplayName("ConfigChangeEvent toString contains change type")
    void toStringContainsChangeType() {
        ConfigChangeEvent event = ConfigChangeEvent.builder()
                .changeType(ConfigChangeEvent.ChangeType.REMOVED).build();
        assertTrue(event.toString().contains("REMOVED"));
    }
}
