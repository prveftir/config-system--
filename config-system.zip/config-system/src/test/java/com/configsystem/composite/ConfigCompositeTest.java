package com.configsystem.composite;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Composite pattern tests")
class ConfigCompositeTest {

    private ConfigNode root;
    private ConfigNode profileNode;
    private ConfigEntry entry;

    @BeforeEach
    void setUp() {
        root = new ConfigNode("ROOT");
        profileNode = new ConfigNode("dev");
        entry = ConfigEntry.builder()
                .key("app.name").value("TestApp")
                .type("STRING").sourceType(ConfigSourceType.FILE).build();
        profileNode.add(new ConfigLeaf(entry));
        root.add(profileNode);
    }

    @Test
    @DisplayName("ConfigNode is not a leaf")
    void configNodeIsNotLeaf() {
        assertFalse(root.isLeaf());
    }

    @Test
    @DisplayName("ConfigLeaf is a leaf")
    void configLeafIsLeaf() {
        ConfigLeaf leaf = new ConfigLeaf(entry);
        assertTrue(leaf.isLeaf());
    }

    @Test
    @DisplayName("Node finds entry by key recursively")
    void nodeFindsEntryByKey() {
        Optional<ConfigEntry> found = root.getEntry("app.name");
        assertTrue(found.isPresent());
        assertEquals("TestApp", found.get().getValue());
    }

    @Test
    @DisplayName("Node returns empty for unknown key")
    void nodeReturnsEmptyForUnknownKey() {
        Optional<ConfigEntry> found = root.getEntry("nonexistent.key");
        assertFalse(found.isPresent());
    }

    @Test
    @DisplayName("getAllEntries returns all leaves")
    void getAllEntriesReturnsAll() {
        ConfigEntry e2 = ConfigEntry.builder()
                .key("db.host").value("localhost")
                .type("STRING").sourceType(ConfigSourceType.FILE).build();
        profileNode.add(new ConfigLeaf(e2));

        List<ConfigEntry> all = root.getAllEntries();
        assertEquals(2, all.size());
    }

    @Test
    @DisplayName("Leaf throws on add()")
    void leafThrowsOnAdd() {
        ConfigLeaf leaf = new ConfigLeaf(entry);
        assertThrows(UnsupportedOperationException.class,
                () -> leaf.add(new ConfigLeaf(entry)));
    }

    @Test
    @DisplayName("Leaf throws on remove()")
    void leafThrowsOnRemove() {
        ConfigLeaf leaf = new ConfigLeaf(entry);
        assertThrows(UnsupportedOperationException.class,
                () -> leaf.remove("any"));
    }

    @Test
    @DisplayName("Leaf returns entry by correct key")
    void leafReturnsEntryByKey() {
        ConfigLeaf leaf = new ConfigLeaf(entry);
        assertTrue(leaf.getEntry("app.name").isPresent());
        assertFalse(leaf.getEntry("other.key").isPresent());
    }

    @Test
    @DisplayName("Node remove deletes child by name")
    void nodeRemoveDeletesChild() {
        ConfigNode module = new ConfigNode("module-a");
        root.add(module);
        assertEquals(2, root.getChildren().size());
        root.remove("module-a");
        assertEquals(1, root.getChildren().size());
    }

    @Test
    @DisplayName("ConfigNode equals by name")
    void configNodeEquals() {
        ConfigNode a = new ConfigNode("alpha");
        ConfigNode b = new ConfigNode("alpha");
        assertEquals(a, b);
    }

    @Test
    @DisplayName("ConfigLeaf equals by entry")
    void configLeafEquals() {
        ConfigLeaf a = new ConfigLeaf(entry);
        ConfigLeaf b = new ConfigLeaf(entry);
        assertEquals(a, b);
    }

    @Test
    @DisplayName("Hierarchy: root -> profile -> module -> param")
    void deepHierarchy() {
        ConfigNode moduleNode = new ConfigNode("cache");
        ConfigEntry cacheEntry = ConfigEntry.builder()
                .key("cache.ttl").value("300")
                .type("INTEGER").sourceType(ConfigSourceType.FILE).build();
        moduleNode.add(new ConfigLeaf(cacheEntry));
        profileNode.add(moduleNode);

        Optional<ConfigEntry> found = root.getEntry("cache.ttl");
        assertTrue(found.isPresent());
        assertEquals("300", found.get().getValue());
    }
}
