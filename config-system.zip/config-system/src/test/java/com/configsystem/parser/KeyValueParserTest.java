package com.configsystem.parser;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.validator.ConfigEntryValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("KeyValueParser tests")
class KeyValueParserTest {

    private KeyValueParser parser;

    @BeforeEach
    void setUp() {
        parser = new KeyValueParser(new ConfigEntryValidator());
    }

    @Test
    @DisplayName("Parses valid key=value line")
    void parsesValidKeyValue() {
        List<ConfigEntry> result = parser.parseLine("app.name=MyApp", ConfigSourceType.FILE);
        assertEquals(1, result.size());
        assertEquals("app.name", result.get(0).getKey());
        assertEquals("MyApp", result.get(0).getValue());
        assertEquals("STRING", result.get(0).getType());
    }

    @Test
    @DisplayName("Parses key=value::TYPE line")
    void parsesKeyValueWithType() {
        List<ConfigEntry> result = parser.parseLine("server.port=8080::INTEGER", ConfigSourceType.FILE);
        assertEquals(1, result.size());
        assertEquals("server.port", result.get(0).getKey());
        assertEquals("8080", result.get(0).getValue());
        assertEquals("INTEGER", result.get(0).getType());
    }

    @Test
    @DisplayName("Parses BOOLEAN type")
    void parsesBooleanType() {
        List<ConfigEntry> result = parser.parseLine("feature.enabled=true::BOOLEAN", ConfigSourceType.FILE);
        assertEquals(1, result.size());
        assertEquals("true", result.get(0).getValue());
        assertEquals("BOOLEAN", result.get(0).getType());
    }

    @Test
    @DisplayName("Sets sourceType from parameter")
    void setsSourceTypeFromParam() {
        List<ConfigEntry> result = parser.parseLine("k=v", ConfigSourceType.DATABASE);
        assertEquals(1, result.size());
        assertEquals(ConfigSourceType.DATABASE, result.get(0).getSourceType());
    }

    @ParameterizedTest
    @ValueSource(strings = {
        "NO_EQUALS_SIGN",
        "=emptyKey",
        "bad.integer=xyz::INTEGER",
        "bad.type=value::UNKNOWN_TYPE",
        "bad.bool=yes::BOOLEAN"
    })
    @DisplayName("Malformed lines return empty list")
    void malformedLinesReturnEmptyList(String line) {
        List<ConfigEntry> result = parser.parseLine(line, ConfigSourceType.FILE);
        assertTrue(result.isEmpty(), "Expected empty for: " + line);
    }

    @Test
    @DisplayName("Null line returns empty list")
    void nullLineReturnsEmptyList() {
        List<ConfigEntry> result = parser.parseLine(null, ConfigSourceType.FILE);
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Blank line returns empty list")
    void blankLineReturnsEmptyList() {
        List<ConfigEntry> result = parser.parseLine("   ", ConfigSourceType.FILE);
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("Value with :: in it is parsed correctly")
    void valueContainingDoubleColon() {
        List<ConfigEntry> result = parser.parseLine("app.url=https://example.com::URL", ConfigSourceType.FILE);
        assertEquals(1, result.size());
        assertEquals("https://example.com", result.get(0).getValue());
        assertEquals("URL", result.get(0).getType());
    }

    @Test
    @DisplayName("loadedAt is set on parsed entry")
    void loadedAtIsSet() {
        List<ConfigEntry> result = parser.parseLine("k=v", ConfigSourceType.FILE);
        assertEquals(1, result.size());
        assertNotNull(result.get(0).getLoadedAt());
    }
}
