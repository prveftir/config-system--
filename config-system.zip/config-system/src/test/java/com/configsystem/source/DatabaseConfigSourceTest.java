package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DatabaseConfigSource tests")
class DatabaseConfigSourceTest {

    private DatabaseConfigSource source;

    @BeforeEach
    void setUp() {
        source = new DatabaseConfigSource();
    }

    @Test
    @DisplayName("Loads stub entries without exception")
    void loadsStubEntriesWithoutException() throws Exception {
        assertDoesNotThrow(() -> source.load());
    }

    @Test
    @DisplayName("Returns db.host entry")
    void returnsDbHostEntry() throws Exception {
        List<ConfigEntry> entries = source.load();
        assertTrue(entries.stream().anyMatch(e -> "db.host".equals(e.getKey())));
    }

    @Test
    @DisplayName("All entries have DATABASE source type")
    void allEntriesHaveDatabaseSourceType() throws Exception {
        List<ConfigEntry> entries = source.load();
        assertFalse(entries.isEmpty());
        entries.forEach(e -> assertEquals(ConfigSourceType.DATABASE, e.getSourceType()));
    }

    @Test
    @DisplayName("Source name is DATABASE")
    void sourceNameIsDatabase() {
        assertEquals("DATABASE", source.getSourceName());
    }
}
