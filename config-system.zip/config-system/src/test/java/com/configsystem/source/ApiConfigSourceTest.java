package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigSourceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ApiConfigSource tests")
class ApiConfigSourceTest {

    private static final String API_URL = "https://config.example.com/api/v1";
    private ApiConfigSource source;

    @BeforeEach
    void setUp() {
        source = new ApiConfigSource(API_URL);
    }

    @Test
    @DisplayName("Loads stub entries without exception")
    void loadsStubEntriesWithoutException() {
        assertDoesNotThrow(() -> source.load());
    }

    @Test
    @DisplayName("Returns api.timeout.ms entry")
    void returnsTimeoutEntry() throws Exception {
        List<ConfigEntry> entries = source.load();
        assertTrue(entries.stream().anyMatch(e -> "api.timeout.ms".equals(e.getKey())));
    }

    @Test
    @DisplayName("All entries have API source type")
    void allEntriesHaveApiSourceType() throws Exception {
        List<ConfigEntry> entries = source.load();
        assertFalse(entries.isEmpty());
        entries.forEach(e -> assertEquals(ConfigSourceType.API, e.getSourceType()));
    }

    @Test
    @DisplayName("Source name contains API URL")
    void sourceNameContainsUrl() {
        assertTrue(source.getSourceName().contains(API_URL));
    }
}
