package com.configsystem.source;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.parser.KeyValueParser;
import com.configsystem.validator.ConfigEntryValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("FileConfigSource tests")
class FileConfigSourceTest {

    private FileConfigSource source;

    @BeforeEach
    void setUp() {
        source = new FileConfigSource(
                "config/test.txt",
                new KeyValueParser(new ConfigEntryValidator()));
    }

    @Test
    @DisplayName("Loads valid entries from test file")
    void loadsValidEntries() throws Exception {
        List<ConfigEntry> entries = source.load();
        assertFalse(entries.isEmpty());
        // Valid lines: test.key, test.number, test.flag
        assertTrue(entries.stream().anyMatch(e -> "test.key".equals(e.getKey())));
        assertTrue(entries.stream().anyMatch(e -> "test.number".equals(e.getKey())));
        assertTrue(entries.stream().anyMatch(e -> "test.flag".equals(e.getKey())));
    }

    @Test
    @DisplayName("Skips malformed lines — does NOT include bad entries")
    void skipsMalformedLines() throws Exception {
        List<ConfigEntry> entries = source.load();
        // no_equals_here has no '=' -> skipped
        assertFalse(entries.stream().anyMatch(e -> "no_equals_here".equals(e.getKey())));
        // bad.integer=xyz::INTEGER -> skipped
        assertFalse(entries.stream().anyMatch(e -> "bad.integer".equals(e.getKey())));
        // unknown.type=value::BADTYPE -> skipped
        assertFalse(entries.stream().anyMatch(e -> "unknown.type".equals(e.getKey())));
    }

    @Test
    @DisplayName("Source name contains resource path")
    void sourceNameContainsPath() {
        assertTrue(source.getSourceName().contains("test.txt"));
    }

    @Test
    @DisplayName("Throws SourceException for missing file")
    void throwsForMissingFile() {
        FileConfigSource bad = new FileConfigSource(
                "config/nonexistent.txt",
                new KeyValueParser(new ConfigEntryValidator()));
        assertThrows(com.configsystem.exception.SourceException.class, bad::load);
    }

    @Test
    @DisplayName("Loaded entries have non-null loadedAt")
    void loadedAtIsNotNull() throws Exception {
        List<ConfigEntry> entries = source.load();
        entries.forEach(e -> assertNotNull(e.getLoadedAt()));
    }
}
