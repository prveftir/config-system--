package com.configsystem.service;

import com.configsystem.entity.ConfigEntry;
import com.configsystem.entity.ConfigProfile;
import com.configsystem.entity.ConfigSourceType;
import com.configsystem.exception.ConfigException;
import com.configsystem.exception.ValidationException;
import com.configsystem.observer.CacheReloadObserver;
import com.configsystem.observer.ConfigChangeEvent;
import com.configsystem.observer.ConfigObserver;
import com.configsystem.source.DatabaseConfigSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ConfigService + Config Singleton integration tests")
class ConfigServiceTest {

    private Config config;
    private ConfigService service;

    @Mock
    private ConfigObserver mockObserver;

    @BeforeEach
    void setUp() {
        config = Config.getInstance();
        config.reset();
        service = new ConfigService(config);
    }

    @AfterEach
    void tearDown() {
        config.reset();
    }

    @Test
    @DisplayName("Singleton returns same instance")
    void singletonReturnsSameInstance() {
        Config a = Config.getInstance();
        Config b = Config.getInstance();
        assertSame(a, b);
    }

    @Test
    @DisplayName("loadSource adds entries accessible via getValue")
    void loadSourceAddsEntries() throws ConfigException {
        ConfigProfile profile = ConfigProfile.builder().name("db-profile").build();
        service.loadSource(new DatabaseConfigSource(), profile);

        Optional<String> host = service.getValue("db.host");
        assertTrue(host.isPresent());
        assertEquals("localhost", host.get());
    }

    @Test
    @DisplayName("loadSource with invalid profile name throws ValidationException")
    void loadSourceInvalidProfileThrows() {
        ConfigProfile bad = ConfigProfile.builder()
                .name("1bad-starts-with-digit").build();
        assertThrows(ValidationException.class,
                () -> service.loadSource(new DatabaseConfigSource(), bad));
    }

    @Test
    @DisplayName("getValue returns empty for missing key")
    void getValueReturnsEmptyForMissingKey() {
        Optional<String> val = service.getValue("nonexistent.key");
        assertFalse(val.isPresent());
    }

    @Test
    @DisplayName("getValueOrDefault returns default for missing key")
    void getValueOrDefaultReturnsFallback() {
        assertEquals("fallback", service.getValueOrDefault("missing.key", "fallback"));
    }

    @Test
    @DisplayName("updateEntry fires observer with ADDED event")
    void updateEntryFiresObserver() {
        service.registerObserver(mockObserver);
        ConfigEntry entry = ConfigEntry.builder()
                .key("new.key").value("newVal")
                .type("STRING").sourceType(ConfigSourceType.FILE)
                .loadedAt(LocalDateTime.now()).build();

        service.updateEntry("test-profile", entry);

        ArgumentCaptor<ConfigChangeEvent> captor =
                ArgumentCaptor.forClass(ConfigChangeEvent.class);
        verify(mockObserver, times(1)).onConfigChanged(captor.capture());
        assertEquals(ConfigChangeEvent.ChangeType.ADDED, captor.getValue().getChangeType());
        assertEquals("new.key", captor.getValue().getEntry().getKey());
    }

    @Test
    @DisplayName("updateEntry twice fires UPDATED on second call")
    void updateEntryTwiceFiresUpdated() throws ConfigException {
        service.registerObserver(mockObserver);
        ConfigProfile profile = ConfigProfile.builder().name("upd-profile").build();
        service.loadSource(new DatabaseConfigSource(), profile);

        ConfigEntry entry = ConfigEntry.builder()
                .key("db.host").value("newhost")
                .type("STRING").sourceType(ConfigSourceType.FILE)
                .loadedAt(LocalDateTime.now()).build();

        service.updateEntry("upd-profile", entry);

        ArgumentCaptor<ConfigChangeEvent> captor =
                ArgumentCaptor.forClass(ConfigChangeEvent.class);
        // 1 call from loadSource (RELOADED) + 1 from updateEntry
        verify(mockObserver, atLeast(1)).onConfigChanged(captor.capture());
        List<ConfigChangeEvent> events = captor.getAllValues();
        boolean hasUpdated = events.stream()
                .anyMatch(e -> e.getChangeType() == ConfigChangeEvent.ChangeType.UPDATED);
        assertTrue(hasUpdated);
    }

    @Test
    @DisplayName("listAll returns all loaded entries")
    void listAllReturnsAllEntries() throws ConfigException {
        ConfigProfile profile = ConfigProfile.builder().name("list-profile").build();
        service.loadSource(new DatabaseConfigSource(), profile);
        List<ConfigEntry> all = service.listAll();
        assertFalse(all.isEmpty());
    }

    @Test
    @DisplayName("registerObserver: CacheReloadObserver receives RELOADED event")
    void cacheReloadObserverReceivesEvent() throws ConfigException {
        CacheReloadObserver observer = new CacheReloadObserver();
        service.registerObserver(observer);
        ConfigProfile profile = ConfigProfile.builder().name("cache-profile").build();
        assertDoesNotThrow(() -> service.loadSource(new DatabaseConfigSource(), profile));
    }

    @Test
    @DisplayName("getEntry returns full ConfigEntry with metadata")
    void getEntryReturnsFull() throws ConfigException {
        ConfigProfile profile = ConfigProfile.builder().name("entry-profile").build();
        service.loadSource(new DatabaseConfigSource(), profile);
        Optional<ConfigEntry> entry = service.getEntry("db.port");
        assertTrue(entry.isPresent());
        assertEquals("INTEGER", entry.get().getType());
        assertEquals(ConfigSourceType.DATABASE, entry.get().getSourceType());
    }
}
