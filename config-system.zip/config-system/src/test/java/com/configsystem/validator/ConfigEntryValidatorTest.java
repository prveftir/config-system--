package com.configsystem.validator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ConfigEntryValidator tests")
class ConfigEntryValidatorTest {

    private ConfigEntryValidator validator;

    @BeforeEach
    void setUp() {
        validator = new ConfigEntryValidator();
    }

    @ParameterizedTest
    @ValueSource(strings = {"STRING", "INTEGER", "LONG", "DOUBLE", "BOOLEAN", "URL", "PATH"})
    @DisplayName("isValidType: allowed types return true")
    void isValidTypeAllowedTypes(String type) {
        assertTrue(validator.isValidType(type));
    }

    @ParameterizedTest
    @ValueSource(strings = {"UNKNOWN", "BADTYPE", "INT", "BOOL", "NUMBER"})
    @DisplayName("isValidType: unknown types return false")
    void isValidTypeUnknownTypes(String type) {
        assertFalse(validator.isValidType(type));
    }

    @Test
    @DisplayName("isValidType: null returns false")
    void isValidTypeNull() {
        assertFalse(validator.isValidType(null));
    }

    @Test
    @DisplayName("isValidType: blank returns false")
    void isValidTypeBlank() {
        assertFalse(validator.isValidType(""));
    }

    @Test
    @DisplayName("isValueMatchingType: valid INTEGER")
    void isValueMatchingTypeInteger() {
        assertTrue(validator.isValueMatchingType("8080", "INTEGER"));
        assertFalse(validator.isValueMatchingType("abc", "INTEGER"));
        assertFalse(validator.isValueMatchingType("", "INTEGER"));
    }

    @Test
    @DisplayName("isValueMatchingType: valid LONG")
    void isValueMatchingTypeLong() {
        assertTrue(validator.isValueMatchingType("9999999999", "LONG"));
        assertFalse(validator.isValueMatchingType("xyz", "LONG"));
    }

    @Test
    @DisplayName("isValueMatchingType: valid DOUBLE")
    void isValueMatchingTypeDouble() {
        assertTrue(validator.isValueMatchingType("3.14", "DOUBLE"));
        assertFalse(validator.isValueMatchingType("notDouble", "DOUBLE"));
    }

    @Test
    @DisplayName("isValueMatchingType: valid BOOLEAN")
    void isValueMatchingTypeBoolean() {
        assertTrue(validator.isValueMatchingType("true", "BOOLEAN"));
        assertTrue(validator.isValueMatchingType("false", "BOOLEAN"));
        assertTrue(validator.isValueMatchingType("TRUE", "BOOLEAN"));
        assertFalse(validator.isValueMatchingType("yes", "BOOLEAN"));
        assertFalse(validator.isValueMatchingType("1", "BOOLEAN"));
    }

    @Test
    @DisplayName("isValueMatchingType: valid URL")
    void isValueMatchingTypeUrl() {
        assertTrue(validator.isValueMatchingType("https://example.com", "URL"));
        assertTrue(validator.isValueMatchingType("http://localhost:8080", "URL"));
        assertFalse(validator.isValueMatchingType("ftp://files.com", "URL"));
        assertFalse(validator.isValueMatchingType("example.com", "URL"));
    }

    @Test
    @DisplayName("isValueMatchingType: valid PATH")
    void isValueMatchingTypePath() {
        assertTrue(validator.isValueMatchingType("/var/log/app.log", "PATH"));
        assertFalse(validator.isValueMatchingType("path\0withNull", "PATH"));
    }

    @Test
    @DisplayName("isValidKey: valid keys")
    void isValidKeyValidKeys() {
        assertTrue(validator.isValidKey("app.name"));
        assertTrue(validator.isValidKey("server.port"));
        assertTrue(validator.isValidKey("db-host"));
        assertTrue(validator.isValidKey("feature_flag"));
    }

    @Test
    @DisplayName("isValidKey: invalid keys")
    void isValidKeyInvalidKeys() {
        assertFalse(validator.isValidKey(null));
        assertFalse(validator.isValidKey(""));
        assertFalse(validator.isValidKey("1starts.with.number"));
        assertFalse(validator.isValidKey(".starts.with.dot"));
    }

    @Test
    @DisplayName("isValueMatchingType: null value returns false")
    void isValueMatchingTypeNullValue() {
        assertFalse(validator.isValueMatchingType(null, "STRING"));
    }

    @Test
    @DisplayName("isValueMatchingType: null type returns false")
    void isValueMatchingTypeNullType() {
        assertFalse(validator.isValueMatchingType("value", null));
    }
}
