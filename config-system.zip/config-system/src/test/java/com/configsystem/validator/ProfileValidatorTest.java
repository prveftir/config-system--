package com.configsystem.validator;

import com.configsystem.entity.ConfigProfile;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ProfileValidator tests")
class ProfileValidatorTest {

    private ProfileValidator validator;

    @BeforeEach
    void setUp() {
        validator = new ProfileValidator();
    }

    @ParameterizedTest
    @ValueSource(strings = {"dev", "production", "qa-env", "profile_1", "Staging"})
    @DisplayName("isValidName: valid names return true")
    void validNamesReturnTrue(String name) {
        assertTrue(validator.isValidName(name));
    }

    @ParameterizedTest
    @ValueSource(strings = {"1bad", "-invalid", ".dot", "", " "})
    @DisplayName("isValidName: invalid names return false")
    void invalidNamesReturnFalse(String name) {
        assertFalse(validator.isValidName(name));
    }

    @Test
    @DisplayName("isValidName: null returns false")
    void nullNameReturnsFalse() {
        assertFalse(validator.isValidName(null));
    }

    @Test
    @DisplayName("isValid: valid profile returns true")
    void isValidReturnsTrueForValidProfile() {
        ConfigProfile profile = ConfigProfile.builder().name("production").build();
        assertTrue(validator.isValid(profile));
    }

    @Test
    @DisplayName("isValid: null profile returns false")
    void isValidReturnsFalseForNull() {
        assertFalse(validator.isValid(null));
    }

    @Test
    @DisplayName("isValid: profile with invalid name returns false")
    void isValidReturnsFalseForBadName() {
        ConfigProfile profile = ConfigProfile.builder().name("1starts-bad").build();
        assertFalse(validator.isValid(profile));
    }
}
